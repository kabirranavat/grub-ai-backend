// Serverless function to call Gemini API
// Deploy this to Vercel/Netlify

export default async function handler(req, res) {
  // Enable CORS
  res.setHeader('Access-Control-Allow-Credentials', true);
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
  res.setHeader('Access-Control-Allow-Headers', 'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version');

  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { description, portionSize, oilLevel } = req.body;

    if (!description) {
      return res.status(400).json({ error: 'Description required' });
    }

    const portionSizes = {
      small: '70% of standard serving',
      medium: 'Standard USDA serving size',
      large: '140% of standard serving',
      xlarge: '175% of standard serving',
      bulk: '200% of standard serving (2x)'
    };

    const oilDescriptions = {
      1: 'No added oil',
      2: 'Light oil (~1 tsp, +40 cal)',
      3: 'Medium oil (~1.5 tsp, +60 cal)',
      4: 'Heavy oil (~1 tbsp, +120 cal)'
    };

    const prompt = `You are a nutrition expert with access to USDA FoodData Central knowledge.

MEAL DESCRIPTION: "${description}"
PORTION SIZE: ${portionSizes[portionSize] || 'Standard USDA serving size'}
OIL LEVEL: ${oilDescriptions[oilLevel] || 'No added oil'}

CRITICAL RULES:
1. BREAK DOWN into SEPARATE ingredients (e.g., "3 flatbreads butter okra" = 3 items)
2. Extract quantities (e.g., "10 raisins" = 10, "3 flatbreads" = 3, "apple" = 1 apple)
3. Look up EACH ingredient in USDA database
4. Calculate calories for EACH ingredient: calories_per_item × quantity
5. Example: "apple" → 1 apple = 95 calories from USDA

Output ONLY this JSON (no markdown, no backticks):
{
  "meal": "${description}",
  "total_calories": number,
  "total_protein_g": number,
  "total_carbs_g": number,
  "total_fiber_g": number,
  "total_sugar_g": number,
  "ingredients": [
    {
      "name": "ingredient name with quantity",
      "calories": number,
      "protein": number,
      "carbs": number,
      "fiber": number,
      "sugar": number,
      "source": "USDA"
    }
  ],
  "confidence_notes": "All values from USDA database"
}`;

    // Call Gemini API from server (no CORS issues!)
    const GEMINI_API_KEY = 'AIzaSyBi8-wfxzpQV8Cs-Kb6G_NbiYRLLKE6MbA';
    
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{
            parts: [{ text: prompt }]
          }],
          generationConfig: {
            temperature: 0.2,
            topK: 40,
            topP: 0.95,
            maxOutputTokens: 2048
          }
        })
      }
    );

    const data = await response.json();
    
    if (!data.candidates || !data.candidates[0] || !data.candidates[0].content) {
      console.error('Gemini API Error:', data);
      throw new Error('Invalid Gemini response');
    }
    
    const responseText = data.candidates[0].content.parts[0].text;
    
    let nutritionData;
    try {
      const cleaned = responseText.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
      nutritionData = JSON.parse(cleaned);
    } catch {
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        nutritionData = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error('Could not parse AI response');
      }
    }
    
    // Return the nutrition data
    return res.status(200).json({
      success: true,
      data: {
        calories: Math.round(nutritionData.total_calories),
        protein: Math.round(nutritionData.total_protein_g),
        carbs: Math.round(nutritionData.total_carbs_g || 0),
        fiber: Math.round(nutritionData.total_fiber_g),
        sugar: Math.round(nutritionData.total_sugar_g),
        ingredients: nutritionData.ingredients,
        reasoning: nutritionData.confidence_notes
      }
    });

  } catch (error) {
    console.error('Error:', error);
    return res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
}
